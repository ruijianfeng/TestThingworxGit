"use strict";

var Module = {
    'locateFile': function (name) {
        return ThingView.modulePath + name;
    },
    '_main': function () {
        ThingView.loaded = true;
        if (!(ThingView.initCB == undefined)) {
            ThingView._completeInit();
            ThingView._setResourcePath(ThingView.resourcePath);
            ThingView.initCB();
        }
        // initLoader();
    }
};

var ThingView = (function () {

    var id = 0;
    var thingView;
    var isUpdated = false;
    var _currentSession = null;
    var _nextCanvasId = 0;
    var resourcePath = null;
    var s_fileversion = "0.7.0.153";
    var s_productversion = "0.7.0-ci+153";
    var s_productname = "ThingView 0.7";

    var returnObj = {
        init: function (path, initCB) {
            ThingView.resourcePath = path;
            ThingView.initCB = initCB;
            if (ThingView.loaded) {
                ThingView._completeInit();
                if (ThingView.initCB) {
                    ThingView.initCB();
                }
            }
            else {
                var head = document.getElementsByTagName('head').item(0);
                var id = document.createElement("SCRIPT");
                var loaderLib;
                if (path) {
                    loaderLib = path + "/libthingview.js";
                    ThingView.modulePath = path + "/";
                }
                else
                    loaderLib = "libthingview.js";

                id.src = loaderLib;
                head.appendChild(id);
            }
        },
        GetVersion: function() {
            return s_version;
        },

        GetFileVersion: function() {
            return s_fileversion;
        },
        _completeInit: function () {
            thingView = Module.ThingView.GetThingView();
            requestAnimationFrame(_DoRender);
        },
        _setResourcePath: function(path) {
            thingView.SetResourcePath(path);
        },
        LoadImage: function (imagename) {
            thingView.LoadImage(imagename);
        },
        CreateSession: function(parentCanvasId) {
            return _createSession(parentCanvasId);
        },
        EnableSession: function(session) {
            _enableSession(session);
        },
        DeleteSession: function(session) {
            _deleteSession(session);
        }
    };
    return returnObj;// End of public functions

    function _DoRender(timeStamp) {
        var doRender = true;
        try
        {
            thingView.DoRender(timeStamp);
        } catch (err)
        {
            console.log("Javascript caught exception "+ err);
            doRender = false;
        }
        if (doRender)
            requestAnimationFrame(_DoRender);
    }

    function _createSession(parentCanvasId)
    {
        var sessionCanvas = document.createElement("canvas");
        var parent = document.getElementById(parentCanvasId);
        sessionCanvas.id = parentCanvasId + "_CreoViewCanvas" + _nextCanvasId;
        _nextCanvasId++;
        sessionCanvas.setAttribute('style', "position: relative; width: 100%; height: 100%");

        var width = parent.clientWidth;
        var height = parent.clientHeight;

        sessionCanvas.width = width;
        sessionCanvas.height = height;
        parent.insertBefore(sessionCanvas, parent.childNodes[0]);

        sessionCanvas.oncontextmenu = function (e) {
            e.preventDefault();
            return false;
        };

        _currentSession = thingView.CreateSession(sessionCanvas.id);
        return _currentSession;
    }

    function _enableSession(session)
    {
        if (_currentSession != null)
        {
            _currentSession.Disable();
        }
        session.Enable();
        _currentSession = session;
    }

    function _deleteSession(session) {
        if (_currentSession == session) {
            _currentSession = null;
        }
        var session_html = Module.castToSession_html(session);
        var canvasId = session_html.GetCanvasName();
        var canvas = document.getElementById(canvasId);
        session.delete();
        session_html.delete();
        if (canvas != null && canvas.parentElement != null)
            canvas.parentElement.removeChild(canvas);

    }

})();



