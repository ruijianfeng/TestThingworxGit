/* bcwti
 *
 * Copyright (c) 2015, 2016 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_runtimePluginVersion = "0.7.0-ci+153"; */

TW.Runtime.Widgets.thingview = function() {
    var thisWidget = this;
    var baseUrl = './';
    var appliedFormatter = false;
    var formatter = thisWidget.getProperty('DataFormatter');
    this.BackgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
    var OccurrenceIdField = thisWidget.getProperty('OccurrenceField');
    if (!OccurrenceIdField) {
        OccurrenceIdField = 'treeId';
    }
    var session;
    var localData;
    var dataLoadtimeoutCancelId;
    var instancesPromise = $.Deferred();
    thisWidget.selectedInstances = [];
    thisWidget.templateUrl = "";
    var MyModelClass;

    var selectionsIndex = [];

    thisWidget.setFormatter = function(f) {
        formatter = f;
    };

    /**
     * Creoview only accepts hex colors, this converts rgb to hex
     */
    function rgb2hex(red, green, blue) {
        var rgb = blue | (green << 8) | (red << 16);
        return '#' + (0x1000000 + rgb).toString(16).slice(1);
    }

    thisWidget.applyFormatter = function() {
        dataLoadtimeoutCancelId = null;
        if (localData && localData.length > 0 && formatter && thisWidget.pvApi) {

            for (var i = 0; i < localData.length; i++) {
                if (appliedFormatter) {
                    //In case the model has already set colors based, reset them
                    thisWidget.pvApi.RestoreInstanceColor(getCachedOccurrencePath(localData[i]));
                    thisWidget.pvApi.SetInstanceTransparency(getCachedOccurrencePath(localData[i]), 1.0);
                }
                var formatResult = TW.getStyleFromStateFormatting({DataRow: localData[i], StateFormatting: formatter});
                if (formatResult.foregroundColor) {
                    appliedFormatter = true;
                    var color, alpha, fgColor = formatResult.foregroundColor;

                    if (fgColor.charAt(0) === '#') {
                        color = fgColor.substring(1);
                    }
                    else if (fgColor.indexOf('rgb') === 0) {
                        var colorParams = fgColor.substring(fgColor.indexOf("(") + 1, fgColor.length - 1).split(',');
                        color = rgb2hex(colorParams[0], colorParams[1], colorParams[2]);
                        if (colorParams[3]) {
                            alpha = parseFloat(colorParams[3], 10);
                            if (alpha >= 0 && alpha <= 1) {
                                thisWidget.pvApi.SetInstanceTransparency(getCachedOccurrencePath(localData[i]), alpha);
                            }
                        }
                    }
                    if (color) {
                        thisWidget.pvApi.SetInstanceColor(getCachedOccurrencePath(localData[i]), color);
                    }
                }
            }
        }
    };
    /**
     * Apply the formatter later as the model is being loaded at the same time
     */
    function applyFormatterWithDebounce() {
        if (dataLoadtimeoutCancelId) {
            clearTimeout(dataLoadtimeoutCancelId);
        }
        dataLoadtimeoutCancelId = setTimeout(thisWidget.applyFormatter, 100);
    }

    this.runtimeProperties = function() {
        return {
            'needsDataLoadingAndError': false
        };
    };


    this.renderHtml = function() {
        TW.log.info('Thing View Widget .renderHtml');
        var color = thisWidget.BackgroundStyle.backgroundColor;
        var html = '';
        html = '<div class="widget-content widget-thingview"\
                style="display:block;'
        if (color) {
            html += 'background-color: ' + color;
        }
        html += '">\
                <div class="thing-view-plugin-wrapper"></div>\
                </div>';
        return html;
    };

    this.afterRender = function() {
        if (window.MyThingView === undefined) {
            TW.log.info('Thing View Widget window.MyThingView: is undefined');
            window.MyThingView = new Object();
            window.MyThingView.thingViewEngineInitialised = false;
            window.MyThingView.thingViewEngineStarting = false;
        }
        TW.log.info('Thing View Widget window.MyThingView: ' + window.MyThingView);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineInitialised: ' + window.MyThingView.thingViewEngineInitialised);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineStarting: ' + window.MyThingView.thingViewEngineStarting);

        thisWidget.productToView = thisWidget.getProperty('ProductToView');
        thisWidget.baseUrl = thisWidget.getProperty('baseUrl');
        var wcDataSource = thisWidget.getProperty('WindchillSourceData');
        if (wcDataSource == true) {
            if (thisWidget.productToView.indexOf("/servlet") > 0) {
                console.log("loading data from Windchill");
                //Set the template param to allow fetching the child files
                var baseUrl = '';
                if (!thisWidget.urlbase) {
                    baseUrl = thisWidget.productToView.substring(0, thisWidget.productToView.indexOf("/servlet"));
                }
                if (!thisWidget.templateUrl) {
                    thisWidget.templateUrl = baseUrl + '/servlet/WindchillAuthGW/com.ptc.wvs.server.util.WVSContentHelper/redirectDownload/FILENAME_KEY?HttpOperationItem=OID1_KEY&ContentHolder=OID2_KEY&u8=1';
                }
            }
        }

        thisWidget.oid = thisWidget.getProperty('oid');
        thisWidget.mapUrl = thisWidget.getProperty('mapUrl');
        thisWidget.markupUrl = thisWidget.getProperty('markupUrl');

        var infoTableValue = thisWidget.getProperty('Views');
        if (infoTableValue === undefined) {
            var dataShapeInfo = undefined;
            TW.Runtime.GetDataShapeInfo("Views", function (info) {
                dataShapeInfo = info;

                // create empty infotable
                var infoTable = {
                    'dataShape': dataShapeInfo,
                    'name': 'views',
                    'description': 'all the views from this session',
                    'rows': []
                };
                thisWidget.setProperty('Views', infoTable);
            });
        }


        thisWidget.updatePVHtml();
    };

    this.updatePVHtml = function() {
        var pluginId = thisWidget.getProperty('Id') + "-plugin";

        thisWidget.thingViewId = "ThingViewContainer-" + pluginId;
        var htmlToWrite = '<div id="';
        htmlToWrite += thisWidget.thingViewId;
        htmlToWrite += '" style="width: 100%; height: 100%; margin-left: auto; margin-right: auto;"></div>';
        thisWidget.jqElement.find('.thing-view-plugin-wrapper').html(htmlToWrite);

        if (window.MyThingView.thingViewEngineInitialised === true) {
            TW.log.info('Thing View Widget already initialised create session');
            thisWidget.CreateSession();
            thisWidget.LoadModel();
        } else if (window.MyThingView.thingViewEngineStarting !== true) {
            TW.log.info('Thing View Widget is not initialised or starting now initialise it');
            TW.log.info("window.MyThingView.thingViewEngineInitialised: " + window.MyThingView.thingViewEngineInitialised);
            window.MyThingView.thingViewEngineStarting = true;

            ThingView.init("../Common/extensions/ptc-thingview-extension/ui/thingview/js/ptc/thingview/", function () {
                window.MyThingView.thingViewEngineInitialised = true;
                thisWidget.CreateSession();
                thisWidget.LoadModel();
            });
        } else {
            var initInterval = setInterval(function(){
                if (window.MyThingView.thingViewEngineInitialised) {
                    TW.log.info('ThingView init complete');
                    window.clearInterval(initInterval);

                    thisWidget.CreateSession();
                    thisWidget.LoadModel();
                } else {
                    TW.log.info('Waiting for ThingView init to complete');
                }
            }, 3000);
        }
    }

    function getCachedOccurrencePath(row) {
        if (!row._cachedOccurrencePath) {
            return thisWidget.constructIdPath(row);
        }
        return row._cachedOccurrencePath;
    }

    this.getIndex = function(value) {
        if (!value || !localData) {
            return;
        }
        var i = localData.length;
        while (i--) {
            if (getCachedOccurrencePath(localData[i]) === value || localData[i][OccurrenceIdField] === value) {
                return i;
            }
        }
    };

    this.getParentRow = function(id) {
        var parent;
        if (!localData) {
            return;
        }

        var i = localData.length;
        while (i--) {
            if (localData[i].objectId === id) {
                return localData[i];
            }
        }

        return null;
    };

    this.constructIdPath = function(row) {
        var id = row[OccurrenceIdField] + '';
        if (id.charAt(0) === '/') {
            return id;
        }
        var parent = row;
        var count = 0;
        while (parent && id.charAt(0) !== '/' && count++ < 100) {
            id = '/' + id;
            parent = this.getParentRow(parent.parentId);
            if (parent) {
                var pid = parent[OccurrenceIdField];
                if (pid !== '/' && pid) {
                    id = pid + id;
                }
            }
        }
        row._cachedOccurrencePath = id;
        return id;
    };

    this.CreateSession = function() {


        MySelectionClass = Module.SelectionEvents.extend("SelectionEvents", {
            OnSelectionBegin: function () {
                thisWidget.selectedInstances = [];
            },
            OnSelectionChanged: function (clear, removed, added) {
                var OccurrenceIdField = thisWidget.getProperty('OccurrenceField');
                if (!OccurrenceIdField)
                    OccurrenceIdField = 'treeId';

                if (clear) {
                    thisWidget.setProperty('SelectedOccurrencePath', "");
                }

                console.log("clear: " + clear + ", removed: " + removed.size() + ", added: " + added.size() );
                if (added.size()) {
                    var idPath = added.get(0);
                    thisWidget.setProperty('SelectedOccurrencePath', idPath);
                }

                if (localData !== undefined) {
                    for (var i=0;i<removed.size();++i) {
                        var idPath = removed.get(i);
                        var index = thisWidget.thisWidget.selectedInstances.indexOf(value);
                        if (index >= 0) {
                            thisWidget.thisWidget.selectedInstances.splice(index, 1);
                        }
                    }
                    for (var i=0;i<added.size();++i) {
                        var idPath = added.get(i);
                        var index = thisWidget.getIndex(idPath);
                        thisWidget.selectedInstances.push(index);
                    }
                }
                thisWidget.updateSelection('Data', thisWidget.selectedInstances);
                thisWidget.jqElement.triggerHandler('SelectionChanged');
            },
            OnSelectionEnd: function () {
            }
        });

        thisWidget.session = ThingView.CreateSession(thisWidget.thingViewId);
        thisWidget.session.SetDragMode(Module.DragMode.NONE);
        thisWidget.session.SetDoNotRoll(false);
        thisWidget.session.AllowPartSelection(thisWidget.getProperty('EnablePartSelection'));
        thisWidget.session.AllowModelSelection(thisWidget.getProperty('EnablePartSelection'));
        thisWidget.session.ShowSpinCenter(thisWidget.getProperty('SpinCenter'));
        thisWidget.updateBackgroundColor();
        thisWidget.session.ShowGnomon(thisWidget.getProperty('Gnomon'));
        thisWidget.session.EnableCrossSiteAccess(thisWidget.getProperty('AllowCORSCredentials'));
        thisWidget.selectionObserver = new MySelectionClass();
        thisWidget.session.RegisterSelectionObserver(thisWidget.selectionObserver);
        thisWidget.cacheSize = thisWidget.getProperty('WindchillCacheSize');

        if ( (thisWidget.getProperty('EnableWindchillFileCache') == true) && (thisWidget.cacheSize != undefined) )
            thisWidget.session.EnableFileCache(thisWidget.cacheSize);
    }

    this.UnloadModel = function() {
        if (thisWidget.session) {
            thisWidget.session.RemoveAllModels(true);
            thisWidget.modelWidget = null;
        }
    }

    this.LoadModel = function() {
        if (thisWidget.session && thisWidget.productToView) {
            MyModelClass = Module.Model.extend("Model", {
                OnLoadComplete: function () {
                    TW.log.info('OnLoadComplete Model Loaded');

                    var defPart = thisWidget.getProperty('DefaultPartStyle', '');
                    TW.log.info("defPart: " + defPart);
                    if (defPart) {
                        thisWidget.DefaultPartStyle = TW.getStyleFromStyleDefinition(defPart);
                        var color = thisWidget.parseRGBA(thisWidget.DefaultPartStyle.foregroundColor);
                        thisWidget.modelWidget.SetColor(parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]));
                    }

                    thisWidget.UpdateLocation();

                    var infoTableValue = thisWidget.getProperty('Views');
                    if (infoTableValue.rows == undefined)
                        infoTableValue.rows = [];

                    var annoSets = thisWidget.modelWidget.GetAnnotationSets();
                    if (annoSets) {
                        for (var i = 0; i < annoSets.size() ; i++) {
                            var setName = annoSets.get(i);
                            infoTableValue.rows.push({ 'name': setName, 'type': 'annotation', 'value': setName});
                        }
                    }

                    var illustrations = thisWidget.modelWidget.GetIllustrations()
                    if (illustrations.size() > 0) {
                        for (var i = 0; i < illustrations.size() ; i++) {
                            var illustrationName = illustrations.get(i).name;
                            infoTableValue.rows.push({ 'name': illustrationName, 'type': 'viewable', 'value': illustrationName});
                        }
                    }

                    var viewStates = thisWidget.modelWidget.GetViewStates();
                    if (viewStates) {
                        for (var i = 0; i < viewStates.size(); i++) {
                            var viewState = viewStates.get(i);
                            var viewStateName = viewState.m_viewStateName;
                            var viewStatePath = viewState.m_viewStatePath;
                            infoTableValue.rows.push({ 'name': viewStateName, 'type': 'viewstate', 'value': viewStatePath});
                        }
                    }
                    thisWidget.setProperty('Views', infoTableValue);
                    thisWidget.jqElement.triggerHandler('Loaded');
                },
                OnLoadError: function () {
                    TW.log.error('Failed to Load Model');
                    thisWidget.UnloadModel();
                },
                OnLoadIllustrationComplete: function () {
                    TW.log.info("OnLoadIllustrationComplete");
                    thisWidget.setProperty('sequenceStepNumber', 0);
                },
                OnLoadIllustrationError: function () {
                    TW.log.error("OnLoadIllustrationError");
                },
                OnSequenceEvent: function (playstate, stepInfo, playpos) {
                    TW.log.info("OnSequenceEvent");
                    thisWidget.setProperty('sequenceStepNumber', stepInfo.number);
                    if (playstate == Module.SequencePlayState.PLAYING)
                        thisWidget.playState = "playing";
                    else if (playstate == Module.SequencePlayState.STOPPED)
                        thisWidget.playState = "stopped";

                    thisWidget.playPosition = 'START';
                    if (playpos == Module.SequencePlayPosition.MIDDLE)
                        thisWidget.playPosition = 'MIDDLE';
                    else if (playpos == Module.SequencePlayPosition.END)
                        thisWidget.playPosition = 'END';

                    if (stepInfo.acknowledge)
                        thisWidget.jqElement.triggerHandler('SequenceStepAcknowledge');
                },
                OnAutoloadStructureLoaded: function () {
                    TW.log.info("OnAutoloadStructureLoaded");
                },
                OnLocationChanged: function () {
                    TW.log.info('OnLocationChanged event fired');
                    thisWidget.jqElement.triggerHandler('LocationChanged');
                    thisWidget.UpdateLocation();
                }
            });


            thisWidget.modelWidget = new MyModelClass();
            thisWidget.modelWidget.type = "Model";
            thisWidget.session.AddModel(thisWidget.modelWidget);
            thisWidget.modelWidget.LoadFromWCURL(thisWidget.productToView, thisWidget.templateUrl, thisWidget.mapUrl, thisWidget.oid, thisWidget.markupUrl, true, true);
            setTimeout(function() {
                thisWidget.session.ShowProgress(true);
            }, 500);
        }
    }

    this.UpdateLocation  = function() {
        var modelLocation = thisWidget.modelWidget.GetLocation();
        thisWidget.setProperty("Orientation", modelLocation.orientation.x + ", " + modelLocation.orientation.y + ", " + modelLocation.orientation.z);
        thisWidget.setProperty("Position", modelLocation.position.x + ", " + modelLocation.position.y + ", " + modelLocation.position.z);
        thisWidget.setProperty("Scale", modelLocation.scale.x + ", " + modelLocation.scale.y + ", " + modelLocation.scale.z);
    }

    this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
        switch (propertyName) {
            case 'Data': {
                if (thisWidget.session)
                    thisWidget.session.DeselectAllInstances();
                else {
                    TW.log.info("DeselectAll cannot be called as model is not loaded");
                }
                thisWidget.selectedInstances.splice(0, thisWidget.selectedInstances.length);
                var i = selectedRowIndices.length;
                var idPathArr = new Module.VectorString();

                while (i--) {
                    var id = getCachedOccurrencePath(localData[selectedRowIndices[i]]);
                    thisWidget.selectedInstances.push(id);
                    idPathArr.push_back(id);
                }
                thisWidget.session.SelectInstances(idPathArr, true);
                if (thisWidget.selectedInstances.length > 0) {
                    thisWidget.setProperty('SelectedOccurrencePath', thisWidget.selectedInstances[thisWidget.selectedInstances.length - 1]);
                } else {
                    thisWidget.setProperty('SelectedOccurrencePath', '');
                }
                thisWidget.jqElement.triggerHandler('SelectionChanged');
            }
            break;
            case 'Views': {
                if (selectedRows.length == 1) {
                    if (selectedRows[0].type == "annotation") {
                        thisWidget.modelWidget.LoadAnnotationSet(selectedRows[0].value);
                    } else if (selectedRows[0].type == "viewable") {
                        thisWidget.modelWidget.LoadIllustration(selectedRows[0].value);
                    } else if (selectedRows[0].type == "viewstate") {
                        thisWidget.modelWidget.LoadViewState(selectedRows[0].name, selectedRows[0].value);
                    }
                } else {
                    TW.log.info("must have only one selected row");
                }
            }
            break;
        }
    }

    this.updateProperty = function(updatePropertyInfo) {
        switch (updatePropertyInfo.TargetProperty) {
            case 'ProductToView': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.productToView = thisWidget.getProperty('ProductToView');

                var wcDataSource = thisWidget.getProperty('WindchillSourceData');
                if (wcDataSource == true) {
                    if (thisWidget.productToView.indexOf("/servlet") > 0) {
                        console.log("loading data from Windchill");
                        //Set the template param to allow fetching the child files
                        var baseUrl = '';
                        if (!thisWidget.urlbase) {
                            baseUrl = thisWidget.productToView.substring(0, thisWidget.productToView.indexOf("/servlet"));
                        }
                        if (!thisWidget.templateUrl) {
                            thisWidget.templateUrl = baseUrl + '/servlet/WindchillAuthGW/com.ptc.wvs.server.util.WVSContentHelper/redirectDownload/FILENAME_KEY?HttpOperationItem=OID1_KEY&ContentHolder=OID2_KEY&u8=1';
                        }
                    }
                }

                TW.log.info('ProductToView property updated unload existing model and load new one: ' + thisWidget.productToView);
                thisWidget.UnloadModel();
                thisWidget.LoadModel();
                break;
            }
            case 'Orientation': {
                TW.log.info('Orientation updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.modelWidget) {
                    var orientation = thisWidget.getProperty('Orientation');
                    var orientArray = orientation.split(",");
                    thisWidget.modelWidget.SetOrientation(Number(orientArray[0]), Number(orientArray[1]), Number(orientArray[2]));
                }
                break;
            }
            case 'Position': {
                TW.log.info('Position updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.modelWidget) {
                    var position = thisWidget.getProperty('Position');
                    var positionArray = orientation.split(",");
                    thisWidget.modelWidget.SetPosition(Number(positionArray[0]), Number(positionArray[1]), Number(positionArray[2]));
                }
                break;
            }
            case 'Scale': {
                TW.log.info('Scale updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.modelWidget) {
                    var scale = thisWidget.getProperty('Scale');
                    thisWidget.modelWidget.SetScale(Number(scale));
                }
                break;
            }
            case 'BackgroundStyle': {
                TW.log.info('BackgroundStyle updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.BackgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
                thisWidget.updateBackgroundColor();
                break;
            }
            case 'Data': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                localData = updatePropertyInfo.ActualDataRows;
                var OccurrenceIdField = thisWidget.getProperty('OccurrenceField');
                if (!OccurrenceIdField)
                    OccurrenceIdField = 'treeId';

                if (localData && localData.length > 0) {
                    var i = localData.length;
                    while (i--) {
                        localData[i]._cachedOccurrencePath = null;
                    }
                }

                for (i in localData) {
                    var formatter = thisWidget.getProperty('DataFormatter');
                    var formatResult = TW.getStyleFromStateFormatting({DataRow: localData[i], StateFormatting: formatter});
                    if (formatResult.foregroundColor) {
                        var color = this.parseRGBA(formatResult.foregroundColor);
                        thisWidget.modelWidget.SetPartColor(localData[i][OccurrenceIdField], parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]), false);
                    }
                }
                break;
            }
            case 'Gnomon': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.session) {
                    var showGnomon = thisWidget.getProperty('Gnomon');
                    if (showGnomon == true) {
                        thisWidget.session.ShowGnomon(true);
                    } else if (showGnomon == false) {
                        thisWidget.session.ShowGnomon(false);
                    }
                }
                break;
            }
            case 'EnablePartSelection': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.session) {
                    var enablePartSelection = thisWidget.getProperty('EnablePartSelection');
                    if (enablePartSelection == true) {
                        thisWidget.session.AllowPartSelection(true);
                        thisWidget.session.AllowModelSelection(true);
                    } else if (enablePartSelection == false) {
                        thisWidget.session.AllowPartSelection(false);
                        thisWidget.session.AllowModelSelection(false);
                    }
                }
                break;
            }
            case 'SpinCenter': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.session) {
                    var showSpinCenter = thisWidget.getProperty('SpinCenter');
                    if (showSpinCenter == true) {
                        thisWidget.session.ShowSpinCenter(true);
                    } else if (showSpinCenter == false) {
                        thisWidget.session.ShowSpinCenter(false);
                    }
                }
                break;
            }
            case 'WindchillSourceData': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
        }
    }

    this.parseRGBA = function(color) {

	     var colorParts;
	     var parsedColor = color.replace(/\s\s*/g,''); // Remove all spaces

	     // Checks for 6 digit hex and converts string to integer
	     if (colorParts = /^#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/.exec(parsedColor))
	         colorParts = [parseInt(colorParts[1], 16), parseInt(colorParts[2], 16), parseInt(colorParts[3], 16)];

	     // Checks for 3 digit hex and converts string to integer
	     else if (colorParts = /^#([\da-fA-F])([\da-fA-F])([\da-fA-F])/.exec(parsedColor))
	         colorParts = [parseInt(colorParts[1], 16) * 17, parseInt(colorParts[2], 16) * 17, parseInt(colorParts[3], 16) * 17];

	     // Checks for rgba and converts string to
	     // integer/float using unary + operator to save bytes
	     else if (colorParts = /^rgba\(([\d]+),([\d]+),([\d]+),([\d]+|[\d]*.[\d]+)\)/.exec(parsedColor))
	         colorParts = [+colorParts[1], +colorParts[2], +colorParts[3], +colorParts[4]];

	     // Checks for rgb and converts string to
	     // integer/float using unary + operator to save bytes
	     else if (colorParts = /^rgb\(([\d]+),([\d]+),([\d]+)\)/.exec(parsedColor))
	         colorParts = [+colorParts[1], +colorParts[2], +colorParts[3]];

	     // Otherwise throw an exception to make debugging easier
	     else
	    	 colorParts = [0,0,0,1];

	     // Performs RGBA conversion by default
	     isNaN(colorParts[3]) && (colorParts[3] = 1);

         if (colorParts[0] != 0)
             colorParts[0] = colorParts[0] / 255;
         if (colorParts[1] != 0)
             colorParts[1] = colorParts[1] / 255;
         if (colorParts[2] != 0)
             colorParts[2] = colorParts[2] / 255;
	     // Adds or removes 4th value based on rgba support
	     // Support is flipped twice to prevent erros if
	     // it's not defined
	     return colorParts;
	};

    this.updateBackgroundColor = function () {
        var color = thisWidget.BackgroundStyle.backgroundColor;
        if (color && color.charAt(0) === '#') {
            color = color.substring(1);
            color = '0x' + color + '00';
            thisWidget.session.SetBackgroundColor(parseInt(color));
        }
    }

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'GetCameraLocation') {
        } else if (serviceName === 'ZoomAll') {
            thisWidget.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
        } else if (serviceName === 'ZoomSelected') {
            thisWidget.session.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
        } else if (serviceName === 'ZoomWindow') {
            thisWidget.session.ZoomView(Module.ZoomMode.ZOOM_WINDOW, 1000.0);
        } else if (serviceName === 'EnableFloor') {
            thisWidget.session.ShowFloor(true,  0x505050E0, 0xE0E0E0E0, "Y");
        } else if (serviceName === 'DisableFloor') {
            thisWidget.session.ShowFloor(false,  0x505050E0, 0xE0E0E0E0, "Y");
        } else if (serviceName === 'EnableDragSelect') {
            thisWidget.session.SetDragMode(Module.DragMode.DRAG);
        } else if (serviceName === 'DisableDragSelect') {
            thisWidget.session.SetDragMode(Module.DragMode.NONE);
        } else if (serviceName === 'Phantom') {
            thisWidget.modelWidget.SetPhantom(0.5);
        } else if (serviceName === 'PlayAnimation') {
            if (thisWidget.playPosition === 'END') {
                var currentStep = thisWidget.getProperty('sequenceStepNumber');
                thisWidget.modelWidget.GoToSequenceStep(Number(currentStep+1), Module.SequencePlayPosition.START, true);
            } else {
                thisWidget.modelWidget.PlayAnimation();
            }
        } else if (serviceName === 'PauseAnimation') {
            thisWidget.modelWidget.PauseAnimation();
        } else if (serviceName === 'StopAnimation') {
            thisWidget.modelWidget.StopAnimation();
        } else if (serviceName === 'RewindSequence') {
            thisWidget.modelWidget.GoToSequenceStep(0, Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'NextSequenceStep') {
            var currentStep = thisWidget.getProperty('sequenceStepNumber');
            if (thisWidget.playState === "playing")
                thisWidget.modelWidget.GoToSequenceStep(Number(currentStep + 1), Module.SequencePlayPosition.START, true);
            else
                thisWidget.modelWidget.GoToSequenceStep(Number(currentStep + 1), Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'PrevSequenceStep') {
            var currentStep = thisWidget.getProperty('sequenceStepNumber');
            if (thisWidget.playState === "stopped") {
                thisWidget.modelWidget.GoToSequenceStep(Number(currentStep-1), Module.SequencePlayPosition.START, false);
            } else if (thisWidget.playState === "playing") {
                thisWidget.modelWidget.GoToSequenceStep(Number(currentStep), Module.SequencePlayPosition.START, true);
            }
        } else if (serviceName === 'PlayTimeline') {
            thisWidget.modelWidget.PlayTimeline();
        } else if (serviceName === 'PauseTimeline') {
            thisWidget.modelWidget.PauseTimeline();
        } else if (serviceName === 'StopTimeline') {
            thisWidget.modelWidget.StopTimeline();
        } else {
            TW.log.error('thingview widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    }

    this.beforeDestroy = function() {
        thisWidget.UnloadModel();
        if (thisWidget.session !== undefined) {
            ThingView.DeleteSession(thisWidget.thingViewId);
        }
        thisWidget.session = undefined;
        TW.log.info('Thing View Widget .beforeDestroy');
        if (thisWidget.jqElement) {
            thisWidget.jqElement.find('img').unbind('click');
        }
        thisWidget.reverseidMap = null;
        localData = thisWidget = formatter = null;
    }
}
