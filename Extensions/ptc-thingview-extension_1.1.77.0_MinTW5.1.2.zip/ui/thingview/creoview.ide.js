/* bcwti
 *
 * Copyright (c) 2016, 2017 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_idePluginVersion = "0.7.0-ci+153"; */

TW.IDE.Widgets.thingview = function() {
    var thisWidget = this;
    this.widgetIconUrl = function() {
        return "../Common/extensions/ptc-thingview-extension/ui/thingview/pview.png";
    };

    this.widgetProperties = function() {
        return {
            'name': 'ThingView',
            'description': 'The ThingView widget allows 3-D models to be displayed.',
            'category': ['Common', 'Components'],
            'isResizable': true,
	        'supportsAutoResize': true,
            'properties': {
                'Width': {
                    'defaultValue': 300
                },
                'Height': {
                    'defaultValue': 200
                },
                'ProductToView': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The url of the file to load.'
                },
                'baseUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The base url of the strucutre.'
                },
                'oid': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The oid of the strucutre.'
                },
                'mapUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The map file url.'
                },
                'markupUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The url to markup content.'
                },
                'Orientation': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The orientation.'
                },
                'Position': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The position.'
                },
                'Scale': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The position.'
                },
                'BackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultShapeUnfilledBackgroundStyle',
                    'description': 'The background color used for the plugin.  All other fields ignored.'
                },
                'Data': {
                    'description': 'Part selection',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'OccurrenceField': {
                    'description': 'Field in the Data that contains the Occurrence path id.  Used to find rows for selection and coloring.',
                    'baseType': 'FIELDNAME',
                    'baseTypeRestriction': "STRING",
                    'sourcePropertyName': 'Data',
                    'defaultValue': 'treeId'
                },
                'SelectedOccurrencePath': {
                    'description': 'The Occurrence path that is selected.',
                    'baseType': 'STRING',
                    'isBindingSource': true,
                    'isBindingTarget': false
                },
                'DataFormatter': {
                    'description': 'Rules for color in the widget.  Only the foregroundColor will be used, both its color value and ' +
                        ' transparency setting.  Set the transparency very low to hide parts for example.  All other fields ignored.',
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data'
                },
                'PreSelection': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'Id of preselected part.',
                    'warnIfNotBoundAsTarget': false
                },
                'Views': {
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'isVisible': true,
                    'description': 'A list of Views (Name, Type, Id).'
                },
                'Gnomon': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display the Gnomon'
                },
                'EnablePartSelection': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Allow part selection'
                },
                'SpinCenter': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display the Spin Center'
                },
                'DefaultPartStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': '',
                    'description': 'The default color for parts'
                },
                'AllowCORSCredentials': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'For CORS requests specify whether cookies will be added to the requests'
                },
                'acknowledgeStepText': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The message to display when a sequence step requires an acknowledgement.'
                },
                'sequenceStepNumber': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The current sequence step number.'
                },
                'sequenceStepName': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The current sequence step name.'
                },
                'WindchillSourceData': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Set to true if ProductToView data is coming from Windchill otherwise set it to false'
                },
                'EnableWindchillFileCache': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Set to true to enable part file cache from Windchill data source.'
                },
                'WindchillCacheSize': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'NUMBER',
                    'isVisible': true,
                    'defaultValue': 1000,
                    'description': 'Cache size in megabytes when using Windchill data source.'
                }
            }
        };
    };

    this.customWidgetEvents = {
        'Loaded': {},
        'Changed': {},
        'LocationChanged': {},
        'SelectionChanged': {},
        'PreSelectionChanged': {},
        'HasAnimation': {},
        'HasSequence': {},
        'SequenceStepAcknowledge': {}
    };

    this.widgetServices = function() {
        return {
            'GetCameraLocation': { 'warnIfNotBound': false },
            'ZoomAll': { 'warnIfNotBound': false },
            'ZoomSelected': { 'warnIfNotBound': false },
            'ZoomWindow': { 'warnIfNotBound': false },
            'EnableDragSelect': { 'warnIfNotBound': false },
            'DisableDragSelect': { 'warnIfNotBound': false },
            'EnableFloor': { 'warnIfNotBound': false },
            'DisableFloor': { 'warnIfNotBound': false },
            'Phantom': { 'warnIfNotBound': false },
            'PlayAnimation': { 'warnIfNotBound': false },
            'PauseAnimation': { 'warnIfNotBound': false },
            'StopAnimation': { 'warnIfNotBound': false },
            'RewindSequence': { 'warnIfNotBound': false },
            'NextSequenceStep': { 'warnIfNotBound': false },
            'PrevSequenceStep': { 'warnIfNotBound': false },
            'PlayTimeline': { 'warnIfNotBound': false },
            'PauseTimeline': { 'warnIfNotBound': false },
            'StopTimeline': { 'warnIfNotBound': false }
        };
    };

    this.widgetEvents = function() {
        return this.customWidgetEvents;
    };

    this.renderHtml = function() {
        var html = '';
        html += '<div class="widget-content widget-thingview"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span style="color: #5bb73b">ThingView</span></td></tr></table></div>';
        return html;
    };

    this.afterLoad = function () {
        var dataShapeInfo = undefined;
        TW.IDE.GetDataShapeInfo("PartSelection", function (info) {
            dataShapeInfo = info;
        });
        var infoTable = {
            'dataShape': dataShapeInfo,
            'name': 'Selection',
            'description': 'Selected Parts',
            'rows': []
        };
        thisWidget.setProperty('Selection', infoTable);
    }

    this.afterSetProperty = function(name, value) {
        if (name === 'Width') {
            this.width = value;
            var canvasElem = document.getElementById('pvCanvas');
            canvasElem.width = value;
        }
        else if (name === 'Height') {
            this.height = value;
            var canvasElem = document.getElementById('pvCanvas');
            canvasElem.height = value;
        }
    };
};
